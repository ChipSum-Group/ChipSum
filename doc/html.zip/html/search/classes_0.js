var searchData=
[
  ['densematrix_33',['DenseMatrix',['../classChipSum_1_1Numeric_1_1DenseMatrix.html',1,'ChipSum::Numeric']]],
  ['densematrix_3c_20scalartype_2c_20sizetype_2c_20backendtype_2c_20props_2e_2e_2e_20_3e_34',['DenseMatrix&lt; ScalarType, SizeType, BackendType, Props... &gt;',['../classChipSum_1_1Numeric_1_1DenseMatrix_3_01ScalarType_00_01SizeType_00_01BackendType_00_01Props_8_8_8_01_4.html',1,'ChipSum::Numeric']]]
];
