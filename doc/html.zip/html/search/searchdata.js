var indexSectionsWithContent =
{
  0: "dgnopsvå",
  1: "dsv",
  2: "dsv",
  3: "dgnopsv",
  4: "å"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "页"
};

