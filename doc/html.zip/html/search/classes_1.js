var searchData=
[
  ['scalar_35',['Scalar',['../classChipSum_1_1Numeric_1_1Scalar.html',1,'ChipSum::Numeric']]],
  ['scalar_3c_20scalartype_2c_20sizetype_2c_20backendtype_2c_20props_2e_2e_2e_20_3e_36',['Scalar&lt; ScalarType, SizeType, BackendType, Props... &gt;',['../classChipSum_1_1Numeric_1_1Scalar_3_01ScalarType_00_01SizeType_00_01BackendType_00_01Props_8_8_8_01_4.html',1,'ChipSum::Numeric']]],
  ['sparsematrix_37',['SparseMatrix',['../classChipSum_1_1Numeric_1_1SparseMatrix.html',1,'ChipSum::Numeric']]],
  ['sparsematrix_3c_20scalartype_2c_20sizetype_2c_20spformat_2c_20backendtype_2c_20props_2e_2e_2e_20_3e_38',['SparseMatrix&lt; ScalarType, SizeType, SpFormat, BackendType, Props... &gt;',['../classChipSum_1_1Numeric_1_1SparseMatrix_3_01ScalarType_00_01SizeType_00_01SpFormat_00_01BackendType_00_01Props_8_8_8_01_4.html',1,'ChipSum::Numeric']]]
];
